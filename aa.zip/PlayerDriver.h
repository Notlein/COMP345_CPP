#pragma once
// #include "Player.h"
#include <string>
#include <iostream>
using namespace std;

void testPlayers();

// ------------ A2 ----------
void addPlayer();