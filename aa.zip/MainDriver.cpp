// #include "MapDriver.h"
// #include "PlayerDriver.h"
// #include "OrdersDriver.h"
// #include "CardsDriver.h"
// #include "GameEngineDriver.h"
// #include <string>

// using namespace std;

// int main()
// {

//     // ---------------------- A1 ----------------------

//     // testPlayers();
//     // testCards();
//     // testOrdersLists();
//     // testGameStates();

//     // ---------------------- A1 ----------------------
//     // ---------------------- A2 ----------------------
//     GameEngine * game = new GameEngine();
//     //game->startupPhase();
    

//     return 0;
// }
