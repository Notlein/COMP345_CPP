#pragma once
#include "GameEngine.h"

using namespace std;

    void testGameStates();