#include "PlayerDriver.h"

// void testPlayers()
// {

//     vector<Order *> src;
//     vector<string *> rrr;

//     vector<string *> tet;

//     string a = "Africa";
//     string b = "Europe";

//     tet.push_back(&a);
//     tet.push_back(&b);

//     vector<string *> card;
//     string e = "bomb";
//     string f = "spy";

//     card.push_back(&e);
//     card.push_back(&f);
//     Player *player1;
//     string name = "Giwon Lee";
//     player1 = new Player(name, tet, card, src);
//     (*player1).issueOrder("issue order 1");
//     (*player1).issueOrder("issue order 2");

//     (*player1).printOrder();

//     (*player1).toAttack();
//     (*player1).toDefend();

//     Player *a2 = new Player(*player1);

//     cout << endl;

//     (*a2).toAttack();

//     cout << "\n";
// }

void addPlayer()
{


    


}
